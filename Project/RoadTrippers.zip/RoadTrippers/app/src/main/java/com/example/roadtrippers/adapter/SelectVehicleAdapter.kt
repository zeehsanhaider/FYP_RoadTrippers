package com.example.roadtrippers.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.AsyncListDiffer
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.roadtrippers.R
import com.example.roadtrippers.databinding.LayoutItemVehicleBinding
import com.example.roadtrippers.model.TransportVehicle

class SelectVehicleAdapter(
    private val context: Context
) : RecyclerView.Adapter<SelectVehicleAdapter.SelectVehicleViewHolder>() {

    var selectedVehiclePosition = -1

    /**
     * VIEW HOLDER
     */
    inner class SelectVehicleViewHolder(val binding: LayoutItemVehicleBinding) :
        RecyclerView.ViewHolder(binding.root)

    /**
     * ADAPTER METHODS
     */
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SelectVehicleViewHolder {
        return SelectVehicleViewHolder(
            LayoutItemVehicleBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: SelectVehicleViewHolder, position: Int) {
        val vehicle = differ.currentList[position]
        with(holder.binding) {
            // Vehicle Information
            txVehicleName.text = vehicle.name
            txExpenseFactor.text = "${vehicle.expenseIncrementFactor} %"
            txMileage.text = "${vehicle.perLitreMileage} Km"
            txSeater.text = "${vehicle.seats} Seater"
            // Loading product image from url
            Glide.with(context).load(vehicle.imgUrl).into(ivVehicleImg)
            // Item click listener
            cardParent.setOnClickListener {
                onItemClickListener?.let { it(vehicle, position) }
            }
            if (position == selectedVehiclePosition) {
                cardParent.setCardBackgroundColor(
                    ContextCompat.getColorStateList(
                        context,
                        R.color.grey_5
                    )
                )
            } else {
                cardParent.setCardBackgroundColor(
                    ContextCompat.getColorStateList(
                        context,
                        R.color.grey_3
                    )
                )
            }
        }
    }

    override fun getItemCount(): Int {
        return differ.currentList.size
    }

    /**
     * DIFF CALLBACK
     */
    private val differCallback = object : DiffUtil.ItemCallback<TransportVehicle>() {
        override fun areItemsTheSame(
            oldItem: TransportVehicle,
            newItem: TransportVehicle
        ): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(
            oldItem: TransportVehicle,
            newItem: TransportVehicle
        ): Boolean {
            return oldItem == newItem
        }
    }
    val differ = AsyncListDiffer(this, differCallback)


    /**
     * ITEM CLICK LISTENERS
     */
    private var onItemClickListener: ((vehicle: TransportVehicle, position: Int) -> Unit)? =
        null

    fun setOnItemClickListener(listener: (vehicle: TransportVehicle, position: Int) -> Unit) {
        onItemClickListener = listener
    }

    /**
     * HELPER FUNCTIONS
     */
    fun getSelectedVehicle(): TransportVehicle {
        return differ.currentList[selectedVehiclePosition]
    }

}