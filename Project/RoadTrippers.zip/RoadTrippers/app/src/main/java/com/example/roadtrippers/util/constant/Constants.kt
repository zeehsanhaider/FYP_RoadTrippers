package com.example.roadtrippers.util.constant

object Constants {

    const val NULL_LONG = 0L
    const val NULL_DOUBLE = 0.0
    const val NULL_STRING = "null"
    const val NULL_INT = 0
    const val NO_ID_ASSIGNED_USER = "NO_ID_ASSIGNED_USER"

}