package com.example.roadtrippers.ui.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.roadtrippers.adapter.TripsAdapter
import com.example.roadtrippers.database.remote.callback.DataChangeListener
import com.example.roadtrippers.database.remote.controller.DatabaseController
import com.example.roadtrippers.databinding.FragmentTripsBinding
import com.example.roadtrippers.model.Trip
import com.example.roadtrippers.util.toast.ToastUtil
import org.koin.android.ext.android.inject

class TripsFragment : Fragment() {

    private lateinit var binding: FragmentTripsBinding
    private lateinit var tripsAdapter: TripsAdapter
    private val databaseController: DatabaseController by inject()
    private val toastUtil: ToastUtil by inject()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentTripsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initComponents()
    }

    private fun initComponents() {
        setTripsRv()
        setListeners()
        fetchAllTrips()
    }

    private fun fetchAllTrips() {

        databaseController.getAllTrips(object : DataChangeListener {
            override fun onDataChange(list: List<Any>) {
                val trips = list as List<Trip>
                tripsAdapter.differ.submitList(trips)
            }

            override fun onCancel(message: String) {
                toastUtil.shortToast(message)
            }
        })
    }

    private fun setTripsRv() {
        with(binding.rvTrips) {
            tripsAdapter = TripsAdapter(requireContext())
            layoutManager = LinearLayoutManager(requireContext(), RecyclerView.VERTICAL, false)
            adapter = tripsAdapter
        }
    }

    private fun setListeners() {
        tripsAdapter.setOnItemClickListener { tripItem, _ ->
            findNavController().navigate(
                TripsFragmentDirections.actionTripsFragmentToTripDetailsFragment(
                    tripId = tripItem.id
                )
            )
        }
    }

    companion object {
        private const val TAG = "TripsFragment"
    }

}